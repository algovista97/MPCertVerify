import { Link } from "react-router-dom";
import { ShieldCheck, Upload, Search, ArrowRight } from "lucide-react";

const HomePage = () => {
  return (
    <div className="relative">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-[120px]" />
      </div>

      <section className="container relative flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] py-24 text-center">
        <div className="animate-fade-up inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border/50 bg-secondary/50 text-sm text-muted-foreground mb-8">
          <ShieldCheck className="h-4 w-4 text-primary" />
          Trusted by 200+ institutions worldwide
        </div>

        <h1 className="animate-fade-up-delay-1 text-balance max-w-3xl text-5xl font-extrabold leading-[1.08] tracking-tight sm:text-6xl lg:text-7xl">
          Academic Certificate{" "}
          <span className="text-primary">Verification</span>
        </h1>

        <p className="animate-fade-up-delay-2 mt-6 max-w-xl text-lg text-muted-foreground text-pretty leading-relaxed">
          Verify any academic credential instantly using cryptographic integrity
          and AI-powered forgery detection.
        </p>

        <div className="animate-fade-up-delay-3 mt-16 grid w-full max-w-2xl gap-6 sm:grid-cols-2">
          <Link to="/upload" className="group">
            <div className="glass-card glow-blue p-8 transition-all duration-200 hover:border-primary/40 hover:bg-card/90 active:scale-[0.98]">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Issue Certificate</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Upload and register new academic credentials securely.
              </p>
              <div className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
                Get started
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </Link>

          <Link to="/verify" className="group">
            <div className="glass-card p-8 transition-all duration-200 hover:border-primary/40 hover:bg-card/90 active:scale-[0.98]">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <Search className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Verify Certificate</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Check authenticity of any certificate in seconds.
              </p>
              <div className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
                Verify now
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
