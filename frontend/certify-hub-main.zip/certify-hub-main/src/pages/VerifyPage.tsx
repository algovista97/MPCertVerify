import { useState, useRef } from "react";
import { Search, Upload, ShieldCheck, ShieldAlert, FileText } from "lucide-react";
import api from "@/lib/api";

const VerifyPage = () => {
  const [activeTab, setActiveTab] = useState<"id" | "upload">("id");

  return (
    <div className="container max-w-2xl py-12">
      <div className="animate-fade-up mb-8">
        <h1 className="text-3xl font-bold">Verify a Certificate</h1>
        <p className="mt-2 text-muted-foreground">
          Check the authenticity of any academic credential.
        </p>
      </div>

      <div className="animate-fade-up-delay-1">
        {/* Tabs */}
        <div className="mb-6 flex rounded-lg border border-border bg-secondary/30 p-1">
          <button
            onClick={() => setActiveTab("id")}
            className={`flex-1 rounded-md px-4 py-2 text-sm font-medium transition-colors ${
              activeTab === "id"
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Verify by ID
          </button>
          <button
            onClick={() => setActiveTab("upload")}
            className={`flex-1 rounded-md px-4 py-2 text-sm font-medium transition-colors ${
              activeTab === "upload"
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Verify by Upload
          </button>
        </div>

        {activeTab === "id" ? <VerifyById /> : <VerifyByUpload />}
      </div>
    </div>
  );
};

function VerifyById() {
  const [certId, setCertId] = useState("");
  const [loading, setLoading] = useState(false);
  const [details, setDetails] = useState<any>(null);
  const [error, setError] = useState("");

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setDetails(null);
    setLoading(true);

    try {
      const { data } = await api.get(`/verify/${certId}`);
      setDetails(data);
    } catch {
      setError("Certificate not found or invalid ID.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleVerify} className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            required
            value={certId}
            onChange={(e) => setCertId(e.target.value)}
            placeholder="Enter Certificate ID"
            className="w-full rounded-lg border border-input bg-background/50 pl-10 pr-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-shadow"
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors active:scale-[0.98]"
        >
          {loading ? "..." : "Verify"}
        </button>
      </form>

      {error && (
        <div className="rounded-lg bg-destructive/10 border border-destructive/20 px-4 py-3 text-sm text-destructive">
          {error}
        </div>
      )}

      {details && (
        <div className="animate-fade-up glass-card p-6 space-y-3">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-success" />
            Certificate Details
          </h3>
          <div className="grid gap-3 text-sm">
            {[
              ["Student", details.student_name],
              ["Degree", details.degree],
              ["Institution", details.institution],
              ["Issued", details.issue_date],
              ["Status", details.status],
            ].map(([label, value]) => (
              <div key={label} className="flex justify-between border-b border-border/50 pb-2">
                <span className="text-muted-foreground">{label}</span>
                <span className="font-medium">{value}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function VerifyByUpload() {
  const [certId, setCertId] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    status: string;
    confidence: number;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped?.type === "application/pdf") setFile(dropped);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    setLoading(true);
    setResult(null);

    try {
      const formData = new FormData();
      formData.append("certificate_id", certId);
      formData.append("file", file);

      const { data } = await api.post("/verify", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setResult({ status: data.status, confidence: data.confidence });
    } catch {
      setResult({ status: "error", confidence: 0 });
    } finally {
      setLoading(false);
    }
  };

  const isAuthentic = result?.status?.toLowerCase() === "authentic";

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="mb-1.5 block text-sm font-medium">Certificate ID</label>
        <input
          required
          value={certId}
          onChange={(e) => setCertId(e.target.value)}
          placeholder="Enter Certificate ID"
          className="w-full rounded-lg border border-input bg-background/50 px-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-shadow"
        />
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`cursor-pointer rounded-xl border-2 border-dashed p-12 text-center transition-colors ${
          dragOver
            ? "border-primary bg-primary/5"
            : file
            ? "border-success/40 bg-success/5"
            : "border-border hover:border-primary/40 hover:bg-card/50"
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf"
          className="hidden"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
        />
        {file ? (
          <div className="flex flex-col items-center gap-2">
            <FileText className="h-10 w-10 text-success" />
            <p className="text-sm font-medium">{file.name}</p>
            <p className="text-xs text-muted-foreground">Click to change</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <Upload className="h-10 w-10 text-muted-foreground" />
            <p className="text-sm font-medium">Upload certificate PDF</p>
            <p className="text-xs text-muted-foreground">Drag & drop or click to browse</p>
          </div>
        )}
      </div>

      <button
        type="submit"
        disabled={loading || !file}
        className="w-full rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors active:scale-[0.98]"
      >
        {loading ? "Analyzing..." : "Verify Certificate"}
      </button>

      {result && result.status !== "error" && (
        <div
          className={`animate-fade-up rounded-xl border-2 p-8 text-center ${
            isAuthentic
              ? "border-success/40 bg-success/5"
              : "border-destructive/40 bg-destructive/5"
          }`}
        >
          <div className="mb-3 flex justify-center">
            {isAuthentic ? (
              <ShieldCheck className="h-12 w-12 text-success" />
            ) : (
              <ShieldAlert className="h-12 w-12 text-destructive" />
            )}
          </div>
          <p
            className={`text-2xl font-extrabold tracking-tight ${
              isAuthentic ? "text-success" : "text-destructive"
            }`}
          >
            {isAuthentic ? "AUTHENTIC" : "TAMPERED"}
          </p>
          <p className="mt-2 text-sm text-muted-foreground">
            Confidence: {(result.confidence * 100).toFixed(1)}%
          </p>
        </div>
      )}
    </form>
  );
}

export default VerifyPage;
